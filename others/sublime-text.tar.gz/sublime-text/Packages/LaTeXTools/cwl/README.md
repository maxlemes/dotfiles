# TeXStudio CWL files

This directory contains vendored Completion Word Lists from TexStudio.

source: https://github.com/texstudio-org/texstudio/tree/master/completion

## LICENSE

File in this directory are deployed under [GPL 3.0 license](LICENSE).
