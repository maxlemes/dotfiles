* `bibtexparser`: From https://github.com/sciunto-org/python-bibtexparser, LGPLv3/BSD dual licensed, see `COPYING_bibtexparser`, revision fb05189f87
* `md2bib.py`: Modified from md2bib.py, https://github.com/reagle/pandoc-wrappers/, which is (c) Copyright 2011-2012 by Joseph Reagle and licensed under the GPLv3.
