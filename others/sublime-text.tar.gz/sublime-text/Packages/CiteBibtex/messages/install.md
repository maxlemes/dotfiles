
## CiteBibtex Initial Configuration

In order to use this plugin, set the path to your global BibTeX file (`bibtex_file`) in the plugin settings, by selecting `Preferences -> Package Settings -> CiteBibtex -> Settings - User`.

See `Preferences -> Package Settings -> CiteBibtex -> Settings - Default` for available options.
