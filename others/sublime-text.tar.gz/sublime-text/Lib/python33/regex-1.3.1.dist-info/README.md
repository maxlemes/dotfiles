# sublime-regex

Python regex module packaged for Sublime Text 3.

Current Version: regex-2017.09.23 (2.4.130)

Author: Matthew Barnett  
Home Page: https://bitbucket.org/mrabarnett/mrab-regex  
License: Python Software Foundation License  
