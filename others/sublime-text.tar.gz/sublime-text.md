# Instalar o pacote 'apt-transport-https' (caso ainda não tenha)
sudo apt update
sudo apt install apt-transport-https curl

# Adicionar a chave GPG do Sublime
curl -fsSL https://download.sublimetext.com/sublimehq-pub.gpg | sudo gpg --dearmor -o /etc/apt/trusted.gpg.d/sublime.gpg

# Adicionar o repositório do Sublime
echo "deb https://download.sublimetext.com/ apt/stable/" | sudo tee /etc/apt/sources.list.d/sublime-text.list

# Atualizar os repositórios
sudo apt update

# instalar sublime text
sudo apt install sublime-text

# configurar o sublime text - copipe a pasta sublime-text para ~/.config
mv sublime-text ~/.config/
